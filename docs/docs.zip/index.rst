.. Pydna documentation master file, created by
   sphinx-quickstart on Wed Jul 17 12:20:24 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Pydna's documentation!
=================================

Contents:

.. toctree::
   :maxdepth: 2

   pydna
   

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

