#!/bin/bash

sphinx-apidoc -f -o . ../pydna

echo `basename $0`
